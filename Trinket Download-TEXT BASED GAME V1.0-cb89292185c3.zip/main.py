import random
import time


def fight_easy_wizard_goblin(goblin_health, money, full_health, damaged_health, damage, x, inventory):
    while goblin_health > 0:
        goblin_damage = random.randint(1, 10)
        damaged_health -= goblin_damage
        print(f"You have {damaged_health} health left.")
        print(f"The goblin dealt {goblin_damage} damage to you.")

        choice = input("What do you want to do?\nPress 1 for inventory\nPress 2 to attack\nPress 3 to run:\n ")

        if choice == '1':
            print("Inventory:", inventory)
        elif choice == '2':
            print("You attacked the goblin!")
            goblin_health -= damage
            print(f"The goblin has {goblin_health} health left.")

        elif choice == '3':
            print("You escaped the goblin!")
            x = 1
            break
        else:
            print("Invalid choice. Please select 1, 2, or 3.")

        if damaged_health <= 0:
            x = 2
            print("You have died and lost 50 coins.")
            time.sleep(3)
            break
        
        if goblin_health <= 0:
            print("You have defeated the goblin!")
            print("You are leaving the arena, please wait...")
            x = 1
            time.sleep(3)
            break


    return x


damage=1
armour=0
goblin_health=20
x=0
full_health = int(input("hello i am THE NARRATOR.you have 300 points to use between health and money, how many points do you want to use in health?\n"))
money = 300 - full_health
print (f"you have {money} coins and {full_health} health")
damaged_health=full_health 
inventory=["stick","healing potion"]
while True:
    while True:
        dec = int(input("press 1 for shop\npress 2 for the arena\npress 3 for luck test\npress 4 for inventory\npress 5 to sleep\npress 6 to quit\npress 7 to chose weapon\npress 8 to chose armour\npress 9 to wander the forest\n"))
        if dec == 1:
            shop=int(input("what shop would you like to visit?\npress 1 for the weapon shop\npress 2 for the armour shop\npress 3 for the potion shop\n"))
            if shop == 1:
                print(f"you have {money} coins")
                item = int(input("hello what item would you like to buy?\npress 1 for basic sword £50\npress 2 for metal sword £150\npress 3 for light saber £3000\npress 4 for crossbow £200\npress 5 for a stick £1\npress 6 for pistol £250\n"))
                if item == 1:
                    if "basic_sword" in inventory:
                        print("you already have that item")
                        break 
                    elif money-50<0:
                        print("you dont have enough money")
                    else:
                        inventory.append("basic sword")
                        print("thank you for your purchase")
                        money = money - 50
                        print("you now have", money, "money left")
                if item == 2:
                    if "metal_sword" in inventory:
                        print("you already have that item")
                        break
                    else:
                        inventory.append("metal sword")
                        print("thank you for your purchase")
                        money = money - 150
                        ms_damage = 15
                        print("you now have", money, "money left")
                if item == 3:
                    if "basic_sword" in inventory:
                        print("you already have that item")
                        break 
                    else:    
                        inventory.append("light saber")
                        print("thank you for your purchase")
                        money = money - 3000
                        print("you now have", money, "money left")
                if item == 4:
                        inventory.append("crossbow")
                        print("thank you for your purchase")
                        money = money - 200
                        print("you now have", money, "money left")  
                if item == 5:
                    if "stick" in inventory:
                            print("you already have that item")
                            break
                    else:
                        inventory.append("stick")
                        print("thank you for your purchase")
                        money = money - 1
                        print("you now have", money, "money left")
                if item == 6:
                    if "pistol" in inventory:
                        print("you already have that item")
                        break
                    else:
                        inventory.append("pistol")
                        print("thank you for your purchase")
                        money = money - 250
                        print("you now have", money, "money left")
                if item == 69420:
                    if "bumbaclart sword" in inventory:
                            print("you already have that item")
                            break
                else:
                    inventory.append("bumbaclart sword")
                    print("thank you for your purchase")
                    money = money - 1
                    print("you now have", money, "money left")
                    break
            if shop == 2:
                print(f"you have {money} money")
                armour = int(input("heloo what armour would you like to buy?\npress 1 for basic armour £50\npress 2 for metal armour £150\npress 3 for dragon armour £2000\n"))
                if armour == 1 and "basic_armour" in inventory:
                    print("you already have that item")
                    break
                elif money-50<0:
                    print("you dont have enough money")
                    break
                else:
                    money=money-50
                    inventory.append("basic armour")
                    print(f"thank you for your purchase. you now have {money} money left")
                    
        if dec == 3:
            print("your luck is being randomly generated\nPlease wait...")
            time.sleep(3)
            luck=random.randint(0,1000)
            if luck < 10:
                gg = random.randint(1, 3)
                if gg == 1:
                    full_health = full_health + 1000
                    print("you now have", full_health, "health")
                if gg == 2:
                    inventory.append("boss_slayer_sword")
                    print("you have been bestowed the BOSS SLAYER SWORD!!")
                elif gg == 3:
                    money += 1000000
                    print("you now have", money, "money")
            else:
                print("sorry you only have", luck, "luck. better luck next time")
        if dec == 2:
            guilt = int(input("YOU ARE NOW IN THE ARENA DO YOU WISH TO FIGHT \npress 1 for yes\npress 2 for no\n"))
            if guilt == 2:
                print("the emperor decided to kill you for not fighting\nGAME OVER\npress 1 to restart\npress 2 to quit\n")
            if guilt == 1:
                print(f"you have {full_health} health")
                difficulty=int(input("what difficulty enemy would you like to fight?\npress 1 for easy(health:20, damage:1-10)\npress 2 for medium(health:50, damage:10-20)\npress 3 for hard(health:70, damage:20-30)\npress 4 for extreme(health:100, damage:30-50)\npress 5 for impossible(health:150, damage:50-100)\npress 6 for boss fight(health:200, damage:100-500)\nENTER AT YOUR OWN RISK\n"))
                if difficulty==1:
                    print("you have encountered a wizard goblin and he has challenged you to a duel\n")
                    while x == 0:
                        x = fight_easy_wizard_goblin(goblin_health, money, full_health, damaged_health, damage, x, inventory)
                        if x == 1:
                            money += random.randint(5, 15)
                            print(f"You now have {money} money.")
                            print("you are gaining your health back please wait!!!")
                            time.sleep(5)
                            x=0
                            break
                        elif x == 2:
                            money -= 50
                            print("you now have", money, "money")
                            print("you are gaining your health back please wait!!!")
                            time.sleep(5)
                            x = 0
                            break
                
            if guilt == 2:
                break
        if dec == 7:
            print("what weapon do you want to use\n")
            selection=input(inventory)
            if selection in inventory:
                damage = 5
            if selection in inventory:
                damage = 15
        if dec == 8:
            print("what armour do you want to equip\n")
            armour_selection=input(inventory)
            if armour_selection in inventory:
                armour = 50
        if dec == 4:
            print("you have",inventory)
        if dec == 6:
            print("GAME OVER")
            quit()
        if dec == 5:
            print("you are sleeping\nPLEASE WAIT...")
            time.sleep(10)
            print("you have awoken your health has been restored")
            damaged_health = full_health 
        if dec == 9:
            while True:
                des=int(input("you have entered the dark forest! Enter at own risk....\npress 1 to continue north\npress 2 to continue east\npress 3 to continue west\npress 4 to head back to town\n"))
                if des == 1: 
                    way=int(input("you are heading north, you come across a dark cave\npress 1 to enter\npress 2 to head back\n"))
                    if way == 1:
                        leave=int(input("you have entered the cave, you feel a strange presence watching you\npress 1 to continue\npress 2 to head back\n"))
                        if leave==1:
                            print("as you head further into the cave you feel your stomach drop, your vision goes thin.something is warning you to leave the cave\n")


                        elif leave==2:
                            print("you left the forest")
                            break


                    if way == 2:
                        print("you left the forest")
                        break





